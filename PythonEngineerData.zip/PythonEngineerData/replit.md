# ADA - Autonomous Data Alignment Agent

## Overview
ADA is a Python-based intelligence platform for HubSpot. It provides a clean, typed CLI interface to fetch contact data from HubSpot via Private App tokens, normalize the data, store it locally, and analyze it for lead quality and business insights.

**Current Status:** Production-ready CLI tool with HubSpot API integration, Intelligence Layer (Phase 3), lead scoring, and business insights.

**Created:** October 24, 2025  
**Phase 3 Completed:** October 24, 2025

## Features
- **HubSpot Integration:** Connects to HubSpot CRM API using Private App tokens
- **Contact Management:** Fetches and normalizes contact data with configurable properties
- **Resilient API Client:** Automatic pagination, rate-limit handling with exponential backoff, 30s timeouts
- **Dual Storage:** Exports to both CSV and SQLite database with upsert functionality
- **Intelligence Layer (Phase 3):**
  - Lead scoring (freshness, engagement, quality)
  - Business insights (dormant leads, top engaged, duplicates, owner load, funnel analysis)
  - Multi-format reporting (CSV, JSON Lines, Markdown, SQLite rollups)
- **Rich CLI:** Beautiful console output with tables, progress indicators, and summaries
- **Type-Safe:** Comprehensive type hints and Pydantic models for data validation

## Project Structure
```
.
├── ada/                      # Main package
│   ├── __init__.py          # Package initialization
│   ├── config.py            # Environment configuration (HUBSPOT_TOKEN)
│   ├── log.py               # Rich console logging utilities
│   ├── models.py            # Pydantic models (Contact, normalization)
│   ├── hubspot_client.py    # HubSpot API client with retry logic
│   ├── storage.py           # CSV and SQLite storage functions
│   ├── analysis.py          # Lead scoring & insight generation (Phase 3)
│   └── reporting.py         # Rich output & SQLite rollups (Phase 3)
├── cli.py                   # CLI entry point with argparse
├── pyproject.toml           # Project dependencies
├── .env.example             # Environment variable template
└── .gitignore               # Git ignore patterns
```

## Setup Instructions

### 1. Set HubSpot Token
You need a HubSpot Private App token. Get one from:
**HubSpot Settings → Integrations → Private Apps**

Set it as an environment variable or use Replit Secrets:
```bash
export HUBSPOT_TOKEN="pat-..."
```

Or add to Replit Secrets with key: `HUBSPOT_TOKEN`

### 2. Install Dependencies
Dependencies are automatically managed via `uv`. They include:
- httpx (HTTP client)
- pydantic (data validation)
- python-dotenv (environment variables)
- tenacity (retry logic)
- rich (console output)

## Usage

### List HubSpot Owners
```bash
python cli.py owners
```
Displays a table of all owners with ID, email, and name.

### Pull Contacts (Phase 2)
```bash
python cli.py pull-contacts --limit 50 --out contacts.csv
```

Options:
- `--limit`: Maximum contacts to fetch (default: 100)
- `--out`: Output CSV file path (default: contacts.csv)

This command:
1. Fetches contacts from HubSpot with pagination
2. Normalizes data into Contact model
3. Saves to CSV file (specified by --out)
4. Saves to SQLite database (ada.db)
5. Displays summary with metrics and duration

### Analyze Contacts (Phase 3: Intelligence Layer)
```bash
python cli.py analyze --source sqlite --path ada.db --out-dir reports
```

Analyzes local contact data to generate:
- **Lead Scores:** Freshness (0-100), Engagement (0-100), Quality (0-100 weighted)
- **Business Insights:** Dormant leads, top engaged, duplicates, owner load, funnel breakdown
- **Outputs:** lead_scores.csv, lead_scores.jsonl, insights.jsonl, summary.md, SQLite rollups

Options:
- `--source`: Data source (sqlite or csv) - required
- `--path`: Path to data file - required
- `--out-dir`: Output directory (default: reports)

### Default Contact Properties
- email
- firstname
- lastname
- phone
- company

## Architecture

### Clean Module Design
- **config.py**: Validates HUBSPOT_TOKEN from environment
- **log.py**: Provides Rich console logger with `get_logger(name)`
- **models.py**: Pydantic Contact model with normalization function
- **hubspot_client.py**: API client with automatic pagination and retry logic
- **storage.py**: Pure functions for CSV and SQLite persistence
- **cli.py**: Argparse-based CLI with two commands

### Error Handling
- Missing token → Clear error message
- API rate limits (429) → Automatic backoff with Retry-After header
- Server errors (5xx) → Exponential backoff retry (up to 5 attempts)
- Partial data → Gracefully fills missing properties with None
- Network timeouts → 30-second timeout per request

### Storage
- **CSV**: Human-readable export with all contact fields
- **SQLite**: `ada.db` with `contacts` table, upsert on id (INSERT OR REPLACE)

## Recent Changes
- **2025-10-24**: Phase 3 - Intelligence Layer
  - Added ada/analysis.py with LeadScore/Insight models and scoring algorithms
  - Implemented insight generators (dormant, top engaged, duplicates, owner load, funnel)
  - Created ada/reporting.py with Rich tables, markdown summaries, SQLite rollups
  - Extended CLI with analyze command supporting CSV and SQLite sources
  - Updated documentation with Phase 3 usage examples
  
- **2025-10-24**: Initial implementation (Phase 1-2)
  - Created all core modules with type hints and docstrings
  - Implemented HubSpot API client with pagination and retry logic
  - Built CLI with owners and pull-contacts commands
  - Added dual storage (CSV + SQLite)
  - Configured Rich logging and console output

## User Preferences
- Python 3.11+
- Clean architecture with small, typed modules
- No frameworks (pure Python with minimal dependencies)
- Environment-based configuration (no hardcoded secrets)
- Resilient error handling with clear logging

## Next Steps (Future Enhancements)
- Incremental sync based on updatedAt timestamps
- Contact search and filtering capabilities
- Support for additional HubSpot objects (Companies, Deals, Tickets)
- Additional export formats (JSON, Parquet)
- Batch processing for large datasets
- Unit tests with mocked API responses
