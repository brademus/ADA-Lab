"""
Data models for HubSpot entities.
"""

from pydantic import BaseModel, Field
from typing import Optional
from datetime import datetime


class Contact(BaseModel):
    """Normalized HubSpot contact model."""
    
    id: str = Field(description="Contact ID")
    email: Optional[str] = Field(default=None, description="Contact email")
    firstname: Optional[str] = Field(default=None, description="First name")
    lastname: Optional[str] = Field(default=None, description="Last name")
    phone: Optional[str] = Field(default=None, description="Phone number")
    company: Optional[str] = Field(default=None, description="Company name")
    hs_object_id: Optional[str] = Field(default=None, description="HubSpot object ID")
    createdAt: Optional[str] = Field(default=None, description="Creation timestamp")
    updatedAt: Optional[str] = Field(default=None, description="Last update timestamp")
    
    class Config:
        """Pydantic configuration."""
        populate_by_name = True


def normalize_hs_contact(raw: dict) -> Contact:
    """
    Normalize raw HubSpot contact data into Contact model.
    
    Args:
        raw: Raw contact dict from HubSpot API.
        
    Returns:
        Normalized Contact instance.
        
    Note:
        Handles missing or partial data gracefully by filling with None.
    """
    properties = raw.get("properties", {})
    
    return Contact(
        id=raw.get("id", ""),
        email=properties.get("email"),
        firstname=properties.get("firstname"),
        lastname=properties.get("lastname"),
        phone=properties.get("phone"),
        company=properties.get("company"),
        hs_object_id=properties.get("hs_object_id"),
        createdAt=raw.get("createdAt") or properties.get("createdate"),
        updatedAt=raw.get("updatedAt") or properties.get("lastmodifieddate"),
    )
