"""
Intelligence Layer: Lead scoring and business insights analysis.
Reads local contact data and computes quality scores and actionable insights.
"""

import csv
import json
import sqlite3
from datetime import datetime, timezone
from typing import Literal, Optional
from pathlib import Path
from collections import defaultdict
import hashlib

from pydantic import BaseModel, Field

from ada.log import get_logger

logger = get_logger(__name__)


class LeadScore(BaseModel):
    """Lead quality score with breakdown."""
    
    contact_id: str = Field(description="Contact ID")
    email: Optional[str] = Field(default=None, description="Contact email")
    freshness: int = Field(description="Freshness score 0-100")
    engagement: int = Field(description="Engagement score 0-100")
    quality: int = Field(description="Overall quality score 0-100")
    reasons: list[str] = Field(default_factory=list, description="Score reasons")


class Insight(BaseModel):
    """Business insight with severity."""
    
    type: str = Field(description="Insight type (dormant, duplicate, etc)")
    title: str = Field(description="Human-readable title")
    details: dict = Field(default_factory=dict, description="Detailed data")
    severity: str = Field(default="info", description="Severity: info, warning, critical")


def load_contacts(source: Literal["sqlite", "csv"], path: str) -> list[dict]:
    """
    Load contacts from local storage.
    
    Args:
        source: Data source type (sqlite or csv).
        path: Path to data file.
        
    Returns:
        List of contact dictionaries.
        
    Raises:
        FileNotFoundError: If path doesn't exist.
        ValueError: If source type is invalid.
    """
    path_obj = Path(path)
    
    if not path_obj.exists():
        raise FileNotFoundError(f"Data file not found: {path}")
    
    if source == "sqlite":
        return _load_from_sqlite(path)
    elif source == "csv":
        return _load_from_csv(path)
    else:
        raise ValueError(f"Invalid source: {source}. Must be 'sqlite' or 'csv'")


def _load_from_sqlite(db_path: str) -> list[dict]:
    """Load contacts from SQLite database."""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    
    try:
        cursor.execute("SELECT * FROM contacts")
        contacts = [dict(row) for row in cursor.fetchall()]
        logger.info(f"Loaded {len(contacts)} contacts from SQLite: {db_path}")
        return contacts
    except sqlite3.OperationalError as e:
        logger.error(f"SQLite error: {e}")
        return []
    finally:
        conn.close()


def _load_from_csv(csv_path: str) -> list[dict]:
    """Load contacts from CSV file."""
    contacts = []
    
    with open(csv_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        contacts = list(reader)
    
    logger.info(f"Loaded {len(contacts)} contacts from CSV: {csv_path}")
    return contacts


def compute_freshness(contact: dict, now_utc: datetime) -> tuple[int, list[str]]:
    """
    Compute freshness score based on most recent activity.
    
    Args:
        contact: Contact dictionary with potential date fields.
        now_utc: Current UTC datetime for comparison.
        
    Returns:
        Tuple of (score 0-100, list of reasons).
        
    Note:
        Checks: lastmodifieddate, last_activity_date, recent_deal_close_date,
        createdAt, updatedAt. Uses most recent signal.
    """
    date_fields = [
        "lastmodifieddate",
        "last_activity_date", 
        "recent_deal_close_date",
        "updatedAt",
        "createdAt",
    ]
    
    most_recent = None
    source_field = None
    
    for field in date_fields:
        value = contact.get(field)
        if not value:
            continue
        
        try:
            dt = _parse_datetime(value)
            if dt and (most_recent is None or dt > most_recent):
                most_recent = dt
                source_field = field
        except Exception:
            continue
    
    if most_recent is None:
        return 10, ["no activity dates found"]
    
    days_ago = (now_utc - most_recent).days
    
    if days_ago <= 3:
        score = 100
    elif days_ago <= 7:
        score = 85
    elif days_ago <= 14:
        score = 70
    elif days_ago <= 30:
        score = 55
    elif days_ago <= 60:
        score = 40
    elif days_ago <= 120:
        score = 25
    else:
        score = 10
    
    reason = f"{source_field} {days_ago}d ago"
    return score, [reason]


def compute_engagement(contact: dict) -> tuple[int, list[str]]:
    """
    Compute engagement score based on interactions and lifecycle.
    
    Args:
        contact: Contact dictionary with engagement signals.
        
    Returns:
        Tuple of (score 0-100, list of reasons).
        
    Note:
        Uses: lifecyclestage, lead_status, num_contacted_notes,
        hs_email_last_open_date, hs_email_last_click_date, last_meeting_booked.
        Scoring is additive with cap at 100.
    """
    score = 0
    reasons = []
    now = datetime.now(timezone.utc)
    
    lifecycle = (contact.get("lifecyclestage") or "").lower()
    lead_status = (contact.get("lead_status") or "").lower()
    
    if lifecycle in ("marketingqualifiedlead", "mql"):
        score += 15
        reasons.append("MQL")
    elif lifecycle in ("salesqualifiedlead", "sql"):
        score += 15
        reasons.append("SQL")
    
    if "disqualified" in lead_status:
        score -= 40
        reasons.append("disqualified")
    elif "bounced" in lead_status or "unsubscribed" in lead_status:
        score -= 60
        reasons.append("bounced/unsubscribed")
    
    if _is_recent(contact.get("hs_email_last_click_date"), now, 30):
        score += 20
        reasons.append("recent click")
    
    if _is_recent(contact.get("hs_email_last_open_date"), now, 30):
        score += 20
        reasons.append("recent open")
    
    if _is_recent(contact.get("last_meeting_booked"), now, 30):
        score += 20
        reasons.append("meeting booked")
    
    num_notes = contact.get("num_contacted_notes")
    if num_notes:
        try:
            if int(num_notes) > 0:
                score += 25
                reasons.append("has notes")
        except (ValueError, TypeError):
            pass
    
    score = max(0, min(100, score))
    
    if not reasons:
        reasons = ["no engagement signals"]
    
    return score, reasons


def score_contact(contact: dict, now_utc: Optional[datetime] = None) -> LeadScore:
    """
    Calculate overall lead score for a contact.
    
    Args:
        contact: Contact dictionary.
        now_utc: Current UTC datetime (defaults to now).
        
    Returns:
        LeadScore with quality, freshness, engagement, and reasons.
        
    Note:
        Quality = 0.6 * freshness + 0.4 * engagement
    """
    if now_utc is None:
        now_utc = datetime.now(timezone.utc)
    
    freshness, fresh_reasons = compute_freshness(contact, now_utc)
    engagement, engage_reasons = compute_engagement(contact)
    
    quality = round(0.6 * freshness + 0.4 * engagement)
    
    all_reasons = fresh_reasons + engage_reasons
    
    return LeadScore(
        contact_id=contact.get("id", ""),
        email=contact.get("email"),
        freshness=freshness,
        engagement=engagement,
        quality=quality,
        reasons=all_reasons,
    )


def insight_dormant(contacts: list[dict], days: int = 30) -> list[Insight]:
    """
    Find contacts with no activity in X days.
    
    Args:
        contacts: List of contact dicts.
        days: Dormancy threshold in days.
        
    Returns:
        List of insights about dormant contacts.
    """
    now = datetime.now(timezone.utc)
    dormant = []
    
    for contact in contacts:
        freshness, _ = compute_freshness(contact, now)
        
        days_threshold_score = 55 if days == 30 else 40
        
        if freshness < days_threshold_score:
            dormant.append(contact.get("email") or contact.get("id"))
    
    if not dormant:
        return []
    
    return [Insight(
        type="dormant",
        title=f"{len(dormant)} contacts dormant >{days} days",
        details={"count": len(dormant), "threshold_days": days, "emails": dormant[:10]},
        severity="warning" if len(dormant) > 20 else "info",
    )]


def insight_top_engaged(scores: list[LeadScore], top_n: int = 10) -> list[Insight]:
    """
    Identify top engaged leads.
    
    Args:
        scores: List of lead scores.
        top_n: Number of top leads to identify.
        
    Returns:
        List containing one insight with top leads.
    """
    sorted_scores = sorted(scores, key=lambda s: s.quality, reverse=True)
    top_leads = sorted_scores[:top_n]
    
    if not top_leads:
        return []
    
    details = {
        "count": len(top_leads),
        "top_leads": [
            {
                "email": s.email,
                "quality": s.quality,
                "freshness": s.freshness,
                "engagement": s.engagement,
            }
            for s in top_leads
        ]
    }
    
    return [Insight(
        type="top_engaged",
        title=f"Top {len(top_leads)} engaged leads",
        details=details,
        severity="info",
    )]


def insight_duplicates_by_email(contacts: list[dict]) -> list[Insight]:
    """
    Detect duplicate contacts by email address.
    
    Args:
        contacts: List of contact dicts.
        
    Returns:
        List of insights about duplicates.
    """
    email_groups = defaultdict(list)
    
    for contact in contacts:
        email = contact.get("email")
        if email:
            email_groups[email.lower()].append(contact.get("id", ""))
    
    duplicates = {email: ids for email, ids in email_groups.items() if len(ids) > 1}
    
    if not duplicates:
        return []
    
    return [Insight(
        type="duplicates",
        title=f"{len(duplicates)} duplicate email groups found",
        details={
            "count": len(duplicates),
            "groups": [
                {"email": email, "contact_ids": ids}
                for email, ids in list(duplicates.items())[:10]
            ],
        },
        severity="warning",
    )]


def insight_owner_load(contacts: list[dict]) -> list[Insight]:
    """
    Analyze contact distribution across owners.
    
    Args:
        contacts: List of contact dicts.
        
    Returns:
        List of insights about owner load imbalance.
    """
    owner_counts = defaultdict(int)
    
    for contact in contacts:
        owner = contact.get("hubspot_owner_id") or contact.get("owner_id") or "unassigned"
        owner_counts[owner] += 1
    
    if not owner_counts:
        return []
    
    counts = list(owner_counts.values())
    median_load = sorted(counts)[len(counts) // 2] if counts else 0
    
    overloaded = []
    for owner, count in owner_counts.items():
        if median_load > 0 and count > median_load * 1.2:
            pct_over = round(((count / median_load) - 1) * 100)
            overloaded.append({"owner": owner, "count": count, "pct_over_median": pct_over})
    
    details = {
        "total_owners": len(owner_counts),
        "median_load": median_load,
        "distribution": dict(owner_counts),
        "overloaded": overloaded,
    }
    
    severity = "warning" if overloaded else "info"
    
    return [Insight(
        type="owner_load",
        title=f"Contact distribution across {len(owner_counts)} owners",
        details=details,
        severity=severity,
    )]


def insight_funnel_counts(contacts: list[dict]) -> list[Insight]:
    """
    Count contacts by lifecycle stage and lead status.
    
    Args:
        contacts: List of contact dicts.
        
    Returns:
        List containing funnel breakdown insight.
    """
    lifecycle_counts = defaultdict(int)
    status_counts = defaultdict(int)
    
    for contact in contacts:
        lifecycle = contact.get("lifecyclestage") or "unknown"
        status = contact.get("lead_status") or "unknown"
        
        lifecycle_counts[lifecycle] += 1
        status_counts[status] += 1
    
    return [Insight(
        type="funnel",
        title="Funnel breakdown",
        details={
            "lifecycle": dict(lifecycle_counts),
            "lead_status": dict(status_counts),
        },
        severity="info",
    )]


def to_csv(items: list, path: str, fieldnames: Optional[list[str]] = None) -> None:
    """
    Write items to CSV file.
    
    Args:
        items: List of dicts or Pydantic models.
        path: Output CSV path.
        fieldnames: Optional field order (auto-detected if None).
    """
    if not items:
        logger.warning(f"No items to write to {path}")
        return
    
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    
    dicts = [item.model_dump() if hasattr(item, "model_dump") else item for item in items]
    
    if fieldnames is None and dicts:
        fieldnames = list(dicts[0].keys())
    
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(dicts)
    
    logger.info(f"Wrote {len(items)} items to CSV: {path}")


def to_jsonl(items: list, path: str) -> None:
    """
    Write items to JSON Lines file.
    
    Args:
        items: List of dicts or Pydantic models.
        path: Output JSONL path.
    """
    if not items:
        logger.warning(f"No items to write to {path}")
        return
    
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    
    with open(path, "w", encoding="utf-8") as f:
        for item in items:
            data = item.model_dump() if hasattr(item, "model_dump") else item
            f.write(json.dumps(data) + "\n")
    
    logger.info(f"Wrote {len(items)} items to JSONL: {path}")


def _parse_datetime(value: str) -> Optional[datetime]:
    """Parse datetime string in various formats."""
    if not value:
        return None
    
    formats = [
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d",
    ]
    
    for fmt in formats:
        try:
            dt = datetime.strptime(value, fmt)
            return dt.replace(tzinfo=timezone.utc) if dt.tzinfo is None else dt
        except ValueError:
            continue
    
    return None


def _is_recent(date_str: Optional[str], now: datetime, days: int) -> bool:
    """Check if date string is within N days of now."""
    if not date_str:
        return False
    
    dt = _parse_datetime(date_str)
    if not dt:
        return False
    
    return (now - dt).days <= days
