"""
Reporting utilities: Rich console output, markdown summaries, and SQLite rollups.
"""

import sqlite3
import json
import hashlib
from datetime import datetime, timezone
from typing import List
from pathlib import Path

from rich.console import Console
from rich.table import Table

from ada.analysis import LeadScore, Insight
from ada.log import get_logger

logger = get_logger(__name__)
console = Console()


def render_summary(scores: List[LeadScore], insights: List[Insight]) -> str:
    """
    Generate markdown summary of analysis results.
    
    Args:
        scores: List of lead scores.
        insights: List of insights.
        
    Returns:
        Markdown-formatted summary string.
    """
    md_lines = ["# ADA Analysis Summary\n"]
    
    if scores:
        qualities = [s.quality for s in scores]
        p50 = sorted(qualities)[len(qualities) // 2] if qualities else 0
        p90_idx = int(len(qualities) * 0.9)
        p90 = sorted(qualities)[p90_idx] if p90_idx < len(qualities) else 0
        max_q = max(qualities) if qualities else 0
        
        md_lines.append(f"## Score Overview\n")
        md_lines.append(f"- Total Contacts: {len(scores)}")
        md_lines.append(f"- Median Quality (P50): {p50}")
        md_lines.append(f"- P90 Quality: {p90}")
        md_lines.append(f"- Max Quality: {max_q}\n")
        
        buckets = _bucket_scores(scores)
        md_lines.append(f"## Score Distribution\n")
        for label, count in buckets.items():
            md_lines.append(f"- {label}: {count}")
        md_lines.append("")
        
        top_10 = sorted(scores, key=lambda s: s.quality, reverse=True)[:10]
        md_lines.append(f"## Top 10 Leads\n")
        for i, score in enumerate(top_10, 1):
            email = score.email or "no-email"
            reason = score.reasons[0] if score.reasons else "none"
            md_lines.append(
                f"{i}. {email} - Q={score.quality}, F={score.freshness}, "
                f"E={score.engagement} ({reason})"
            )
        md_lines.append("")
    
    if insights:
        md_lines.append(f"## Insights ({len(insights)} total)\n")
        for insight in insights:
            md_lines.append(f"### {insight.title}")
            md_lines.append(f"- Type: {insight.type}")
            md_lines.append(f"- Severity: {insight.severity}")
            if insight.type == "funnel":
                lifecycle = insight.details.get("lifecycle", {})
                md_lines.append(f"- Lifecycle: {json.dumps(lifecycle, indent=2)}")
            elif insight.type == "owner_load":
                overloaded = insight.details.get("overloaded", [])
                if overloaded:
                    md_lines.append(f"- Overloaded owners: {len(overloaded)}")
            md_lines.append("")
    
    return "\n".join(md_lines)


def print_rich_summary(scores: List[LeadScore], insights: List[Insight]) -> None:
    """
    Print Rich-formatted console summary.
    
    Args:
        scores: List of lead scores.
        insights: List of insights.
    """
    console.print("\n[bold cyan]ADA Analysis Summary[/bold cyan]\n")
    
    if not scores:
        console.print("[yellow]No scores to display[/yellow]")
        return
    
    qualities = [s.quality for s in scores]
    p50 = sorted(qualities)[len(qualities) // 2] if qualities else 0
    p90_idx = int(len(qualities) * 0.9)
    p90 = sorted(qualities)[p90_idx] if p90_idx < len(qualities) else 0
    max_q = max(qualities) if qualities else 0
    
    console.print(
        f"[bold]Scores:[/bold] {len(scores)} contacts  |  "
        f"P50: {p50}  P90: {p90}  Max: {max_q}"
    )
    
    buckets = _bucket_scores(scores)
    bucket_str = "  | ".join([f"{label}: {count}" for label, count in buckets.items()])
    console.print(f"[bold]Buckets:[/bold] {bucket_str}\n")
    
    top_table = Table(title="Top 10 Leads", show_header=True, header_style="bold magenta")
    top_table.add_column("#", style="dim", width=3)
    top_table.add_column("Email", style="cyan")
    top_table.add_column("Q", justify="right", style="green")
    top_table.add_column("F", justify="right", style="blue")
    top_table.add_column("E", justify="right", style="yellow")
    top_table.add_column("Reason", style="dim")
    
    top_10 = sorted(scores, key=lambda s: s.quality, reverse=True)[:10]
    for i, score in enumerate(top_10, 1):
        email = score.email or "no-email"
        reason = score.reasons[0] if score.reasons else "none"
        top_table.add_row(
            str(i),
            email[:30],
            str(score.quality),
            str(score.freshness),
            str(score.engagement),
            reason[:40],
        )
    
    console.print(top_table)
    console.print()
    
    if insights:
        console.print(f"[bold]Insights:[/bold]")
        for insight in insights:
            severity_color = {
                "critical": "red",
                "warning": "yellow",
                "info": "cyan"
            }.get(insight.severity, "white")
            
            console.print(f"  [{severity_color}]•[/{severity_color}] {insight.title}")
            
            if insight.type == "funnel":
                lifecycle = insight.details.get("lifecycle", {})
                lc_str = ", ".join([f"{k}: {v}" for k, v in lifecycle.items()])
                console.print(f"    Lifecycle: {lc_str}")
            elif insight.type == "owner_load":
                overloaded = insight.details.get("overloaded", [])
                if overloaded:
                    for owner_info in overloaded[:3]:
                        console.print(
                            f"    Owner {owner_info['owner']}: "
                            f"+{owner_info['pct_over_median']}% over median"
                        )
        
        console.print()


def write_rollups_sqlite(
    db_path: str,
    scores: List[LeadScore],
    insights: List[Insight]
) -> None:
    """
    Write analysis rollups to SQLite database.
    
    Args:
        db_path: SQLite database path.
        scores: List of lead scores.
        insights: List of insights.
        
    Note:
        Creates tables: lead_scores, insights.
        Upserts by contact_id and insight id (hash of type+title).
    """
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS lead_scores (
            contact_id TEXT PRIMARY KEY,
            email TEXT,
            freshness INTEGER,
            engagement INTEGER,
            quality INTEGER,
            updated_at TEXT
        )
    """)
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS insights (
            id TEXT PRIMARY KEY,
            type TEXT,
            title TEXT,
            severity TEXT,
            created_at TEXT,
            details_json TEXT
        )
    """)
    
    now_iso = datetime.now(timezone.utc).isoformat()
    
    for score in scores:
        cursor.execute("""
            INSERT OR REPLACE INTO lead_scores 
            (contact_id, email, freshness, engagement, quality, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            score.contact_id,
            score.email,
            score.freshness,
            score.engagement,
            score.quality,
            now_iso,
        ))
    
    for insight in insights:
        insight_id = hashlib.sha1(
            f"{insight.type}:{insight.title}".encode()
        ).hexdigest()
        
        cursor.execute("""
            INSERT OR REPLACE INTO insights 
            (id, type, title, severity, created_at, details_json)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (
            insight_id,
            insight.type,
            insight.title,
            insight.severity,
            now_iso,
            json.dumps(insight.details),
        ))
    
    conn.commit()
    conn.close()
    
    logger.info(
        f"Wrote {len(scores)} scores and {len(insights)} insights to {db_path}"
    )


def _bucket_scores(scores: List[LeadScore]) -> dict[str, int]:
    """Bucket scores into ranges."""
    buckets = {
        "0-39": 0,
        "40-59": 0,
        "60-79": 0,
        "80-100": 0,
    }
    
    for score in scores:
        q = score.quality
        if q < 40:
            buckets["0-39"] += 1
        elif q < 60:
            buckets["40-59"] += 1
        elif q < 80:
            buckets["60-79"] += 1
        else:
            buckets["80-100"] += 1
    
    return buckets
