"""
Logging utilities using Rich console.
"""

from rich.console import Console
from rich.logging import RichHandler
import logging
from typing import Optional


_console: Optional[Console] = None


def get_console() -> Console:
    """
    Get or create the shared Rich console instance.
    
    Returns:
        Configured Console instance.
    """
    global _console
    if _console is None:
        _console = Console()
    return _console


def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """
    Create a logger with Rich handler.
    
    Args:
        name: Logger name (typically __name__).
        level: Logging level (default: INFO).
        
    Returns:
        Configured logger instance.
    """
    logger = logging.getLogger(name)
    
    if not logger.handlers:
        logger.setLevel(level)
        
        handler = RichHandler(
            console=get_console(),
            show_time=True,
            show_path=False,
            rich_tracebacks=True,
        )
        handler.setFormatter(logging.Formatter("%(message)s"))
        logger.addHandler(handler)
    
    return logger
