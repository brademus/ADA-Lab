"""
Configuration management for ADA.
Reads and validates environment variables.
"""

import os
from typing import Optional


class ConfigError(Exception):
    """Raised when configuration is invalid or missing."""
    pass


class Config:
    """Configuration for ADA application."""
    
    def __init__(self) -> None:
        """Initialize configuration from environment variables."""
        self.hubspot_token: str = self._get_hubspot_token()
    
    def _get_hubspot_token(self) -> str:
        """
        Retrieve and validate HUBSPOT_TOKEN from environment.
        
        Returns:
            The HubSpot API token.
            
        Raises:
            ConfigError: If token is missing or empty.
        """
        token: Optional[str] = os.environ.get("HUBSPOT_TOKEN")
        
        if not token or not token.strip():
            raise ConfigError(
                "HUBSPOT_TOKEN missing or invalid. "
                "Set it via: export HUBSPOT_TOKEN='pat-...' or use Replit Secrets."
            )
        
        return token.strip()


def get_config() -> Config:
    """
    Get validated configuration instance.
    
    Returns:
        Configured Config instance.
        
    Raises:
        ConfigError: If configuration is invalid.
    """
    return Config()
