"""
Storage utilities for persisting contact data.
Supports CSV and SQLite formats.
"""

import csv
import sqlite3
from typing import List
from pathlib import Path

from ada.models import Contact
from ada.log import get_logger

logger = get_logger(__name__)


def write_contacts_csv(path: str, contacts: List[Contact]) -> None:
    """
    Write contacts to CSV file.
    
    Args:
        path: Output CSV file path.
        contacts: List of Contact instances to write.
    """
    if not contacts:
        logger.warning(f"No contacts to write to {path}")
        return
    
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    
    with open(path, "w", newline="", encoding="utf-8") as f:
        fieldnames = [
            "id", "email", "firstname", "lastname", 
            "phone", "company", "hs_object_id", 
            "createdAt", "updatedAt"
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        
        for contact in contacts:
            writer.writerow(contact.model_dump())
    
    logger.info(f"Wrote {len(contacts)} contacts to {path}")


def write_contacts_sqlite(db_path: str, contacts: List[Contact]) -> None:
    """
    Write contacts to SQLite database with upsert (insert or replace).
    
    Args:
        db_path: SQLite database file path.
        contacts: List of Contact instances to write.
        
    Note:
        Creates 'contacts' table if it doesn't exist.
        Uses REPLACE to upsert based on id.
    """
    if not contacts:
        logger.warning(f"No contacts to write to {db_path}")
        return
    
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS contacts (
            id TEXT PRIMARY KEY,
            email TEXT,
            firstname TEXT,
            lastname TEXT,
            phone TEXT,
            company TEXT,
            hs_object_id TEXT,
            createdAt TEXT,
            updatedAt TEXT
        )
    """)
    
    for contact in contacts:
        data = contact.model_dump()
        cursor.execute("""
            INSERT OR REPLACE INTO contacts 
            (id, email, firstname, lastname, phone, company, hs_object_id, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            data["id"],
            data["email"],
            data["firstname"],
            data["lastname"],
            data["phone"],
            data["company"],
            data["hs_object_id"],
            data["createdAt"],
            data["updatedAt"],
        ))
    
    conn.commit()
    conn.close()
    
    logger.info(f"Wrote {len(contacts)} contacts to {db_path}")
