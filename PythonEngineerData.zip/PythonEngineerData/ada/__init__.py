"""
ADA - Autonomous Data Alignment Agent
HubSpot Data Connection Layer
"""

__version__ = "0.1.0"
