"""
HubSpot API client with pagination, rate-limiting, and retry logic.
"""

import httpx
from typing import Iterator, List, Optional, Dict, Any
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
)
import time

from ada.log import get_logger

logger = get_logger(__name__)


class HubSpotAPIError(Exception):
    """Raised when HubSpot API returns an error."""
    pass


class HubSpotClient:
    """
    Client for interacting with HubSpot CRM API.
    
    Handles authentication, pagination, rate-limiting, and retries.
    """
    
    def __init__(
        self, 
        token: str, 
        base_url: str = "https://api.hubapi.com",
        timeout: float = 30.0
    ) -> None:
        """
        Initialize HubSpot client.
        
        Args:
            token: HubSpot Private App access token.
            base_url: Base URL for HubSpot API.
            timeout: Request timeout in seconds.
        """
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._client: Optional[httpx.Client] = None
    
    def _get_client(self) -> httpx.Client:
        """Get or create HTTP client with proper headers."""
        if self._client is None:
            self._client = httpx.Client(
                headers={
                    "Authorization": f"Bearer {self.token}",
                    "Content-Type": "application/json",
                },
                timeout=self.timeout,
            )
        return self._client
    
    def close(self) -> None:
        """Close the HTTP client."""
        if self._client is not None:
            self._client.close()
            self._client = None
    
    def __enter__(self) -> "HubSpotClient":
        """Context manager entry."""
        return self
    
    def __exit__(self, *args: Any) -> None:
        """Context manager exit."""
        self.close()
    
    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=60),
        retry=retry_if_exception_type((httpx.HTTPStatusError, httpx.TimeoutException)),
        reraise=True,
    )
    def _request(
        self, 
        method: str, 
        endpoint: str, 
        params: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Make HTTP request with retry logic.
        
        Args:
            method: HTTP method (GET, POST, etc.).
            endpoint: API endpoint path.
            params: Query parameters.
            
        Returns:
            Response JSON as dict.
            
        Raises:
            HubSpotAPIError: If API returns error status.
            httpx.HTTPStatusError: For retryable HTTP errors.
        """
        url = f"{self.base_url}{endpoint}"
        client = self._get_client()
        
        try:
            response = client.request(method, url, params=params)
            
            if response.status_code == 429:
                retry_after = int(response.headers.get("Retry-After", 5))
                logger.warning(f"Rate limited. Retrying after {retry_after}s...")
                time.sleep(retry_after)
                response.raise_for_status()
            
            response.raise_for_status()
            return response.json()
            
        except httpx.HTTPStatusError as e:
            if e.response.status_code in (429, 500, 502, 503, 504):
                logger.warning(f"HTTP {e.response.status_code}, retrying...")
                raise
            else:
                raise HubSpotAPIError(
                    f"HubSpot API error {e.response.status_code}: {e.response.text}"
                ) from e
    
    def list_contacts(
        self,
        limit: int = 100,
        properties: Optional[List[str]] = None,
    ) -> Iterator[Dict[str, Any]]:
        """
        List contacts with pagination.
        
        Args:
            limit: Maximum number of contacts to fetch (API max: 100 per page).
            properties: List of properties to retrieve. 
                       Defaults to: email, firstname, lastname, phone, company.
                       
        Yields:
            Contact dicts from HubSpot API.
            
        Note:
            Automatically handles pagination using 'after' cursor.
            Sets propertiesWithHistory=false and archived=false.
        """
        if properties is None:
            properties = ["email", "firstname", "lastname", "phone", "company"]
        
        page_limit = min(limit, 100)
        fetched = 0
        after = None
        
        while fetched < limit:
            params: Dict[str, Any] = {
                "limit": min(page_limit, limit - fetched),
                "properties": ",".join(properties),
                "propertiesWithHistory": "false",
                "archived": "false",
            }
            
            if after:
                params["after"] = after
            
            logger.debug(f"Fetching contacts page (after={after}, limit={params['limit']})")
            
            data = self._request("GET", "/crm/v3/objects/contacts", params=params)
            
            results = data.get("results", [])
            for contact in results:
                yield contact
                fetched += 1
                if fetched >= limit:
                    break
            
            paging = data.get("paging", {})
            after = paging.get("next", {}).get("after")
            
            if not after or not results:
                break
        
        logger.info(f"Fetched {fetched} contacts total")
    
    def list_owners(self) -> List[Dict[str, Any]]:
        """
        List all owners in the HubSpot account.
        
        Returns:
            List of owner dicts with id, email, firstName, lastName.
            
        Note:
            Owners endpoint doesn't use pagination in the same way.
        """
        logger.debug("Fetching owners")
        
        data = self._request("GET", "/crm/v3/owners")
        owners = data.get("results", [])
        
        logger.info(f"Fetched {len(owners)} owners")
        return owners
