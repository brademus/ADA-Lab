# ADA - Autonomous Data Alignment Agent

A Python CLI tool for fetching HubSpot contact data via Private App tokens, normalizing fields, and storing locally in CSV and SQLite formats.

## Features

- 🔗 **HubSpot Integration**: Connect via Private App tokens
- 📊 **Contact Management**: Fetch and normalize contact data
- 🔄 **Automatic Pagination**: Handles large datasets seamlessly
- ⚡ **Rate Limiting**: Exponential backoff for 429/5xx errors
- 💾 **Dual Storage**: CSV + SQLite with upsert functionality
- 🎨 **Rich Console**: Beautiful CLI output with tables and progress indicators
- 🔒 **Type-Safe**: Comprehensive type hints and Pydantic validation

## Prerequisites

- Python 3.11+
- HubSpot Private App token (see setup below)

## Setup

### 1. Get HubSpot Private App Token

1. Go to your HubSpot account
2. Navigate to **Settings → Integrations → Private Apps**
3. Create a new Private App or use an existing one
4. Copy the access token (starts with `pat-`)

### 2. Set Environment Variable

**Option A: Export in shell**
```bash
export HUBSPOT_TOKEN="pat-your-token-here"
```

**Option B: Use Replit Secrets**
- Go to the "Secrets" tab in Replit
- Add key: `HUBSPOT_TOKEN`
- Add value: `pat-your-token-here`

## Usage

### List Owners

Displays all HubSpot owners in your account:

```bash
python cli.py owners
```

**Expected Output:**
```
┏━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━┓
┃ ID       ┃ Email                 ┃ Name          ┃
┡━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━┩
│ 12345678 │ john@company.com      │ John Doe      │
│ 87654321 │ jane@company.com      │ Jane Smith    │
└──────────┴───────────────────────┴───────────────┘
```

### Pull Contacts

Fetch contacts and save to CSV and SQLite:

```bash
python cli.py pull-contacts --limit 50 --out contacts.csv
```

**Options:**
- `--limit`: Maximum contacts to fetch (default: 100)
- `--out`: Output CSV file path (default: contacts.csv)

**Expected Output:**
```
Fetching up to 50 contacts from HubSpot...
✓ Fetched and normalized 50 contacts
✓ Saved to contacts.csv
✓ Saved to ada.db

                  Summary                   
┏━━━━━━━━━━━━━━━━┳━━━━━━━━━━━━━━━━━━━━━━┓
┃ Metric         ┃ Value                ┃
┡━━━━━━━━━━━━━━━━╇━━━━━━━━━━━━━━━━━━━━━━┩
│ Total Fetched  │ 50                   │
│ Normalized     │ 50                   │
│ Written to CSV │ contacts.csv         │
│ Written to DB  │ ada.db               │
│ Duration       │ 2.34s                │
└────────────────┴──────────────────────┘
```

### Analyze Contacts (Phase 3: Intelligence Layer)

Analyze contact data to generate lead scores and business insights:

```bash
python cli.py analyze --source sqlite --path ada.db --out-dir reports
```

Or analyze from CSV:
```bash
python cli.py analyze --source csv --path contacts.csv --out-dir reports
```

**Options:**
- `--source`: Data source type (`sqlite` or `csv`) - **required**
- `--path`: Path to data file (e.g., `ada.db` or `contacts.csv`) - **required**
- `--out-dir`: Output directory for reports (default: `reports`)

**What It Does:**
1. **Loads contacts** from local storage (no network calls)
2. **Scores each contact** with:
   - **Freshness score** (0-100): Based on most recent activity date
   - **Engagement score** (0-100): Based on lifecycle stage, email interactions, meetings
   - **Quality score** (0-100): Weighted combination (60% freshness + 40% engagement)
3. **Generates insights**:
   - Dormant leads (>30 days inactive)
   - Top engaged leads (top 10)
   - Duplicate contacts by email
   - Owner workload distribution
   - Funnel breakdown by lifecycle stage
4. **Outputs**:
   - `reports/lead_scores.csv` - All contact scores
   - `reports/lead_scores.jsonl` - Scores in JSON Lines format
   - `reports/insights.jsonl` - Business insights
   - `reports/summary.md` - Markdown summary
   - Updates `ada.db` with `lead_scores` and `insights` tables

**Expected Console Output:**
```
Loading contacts from sqlite: ada.db...
✓ Loaded 128 contacts
Scoring contacts...
✓ Scored 128 contacts
Generating insights...
✓ Generated 5 insights
Saving reports to reports/...
✓ Saved lead_scores.csv
✓ Saved lead_scores.jsonl
✓ Saved insights.jsonl
✓ Saved summary.md
Writing rollups to ada.db...
✓ Updated ada.db

ADA Analysis Summary

Scores: 128 contacts  |  P50: 62  P90: 88  Max: 100
Buckets: 0-39: 18  | 40-59: 27 | 60-79: 51 | 80-100: 32

                          Top 10 Leads                           
┏━━━┳━━━━━━━━━━━━━━━━━━━━┳━━━━━┳━━━━━┳━━━━━┳━━━━━━━━━━━━━━━━┓
┃ # ┃ Email              ┃   Q ┃   F ┃   E ┃ Reason         ┃
┡━━━╇━━━━━━━━━━━━━━━━━━━━╇━━━━━╇━━━━━╇━━━━━╇━━━━━━━━━━━━━━━━┩
│ 1 │ alice@acme.com     │  92 │  90 │  95 │ recent click   │
│ 2 │ bob@beta.io        │  86 │  85 │  88 │ meeting booked │
...

Insights:
  • 37 contacts dormant >30 days
  • Top 10 engaged leads
  • 6 duplicate email groups found
  • Contact distribution across 4 owners
    Owner 123: +27% over median
  • Funnel breakdown
    Lifecycle: subscriber: 22, lead: 54, mql: 18, sql: 9, ...

Analysis complete in 1.23s
Reports saved to: reports/
```

### View Help

```bash
python cli.py --help
python cli.py owners --help
python cli.py pull-contacts --help
python cli.py analyze --help
```

## Project Structure

```
.
├── ada/                      # Main package
│   ├── __init__.py          # Package initialization
│   ├── config.py            # Environment configuration
│   ├── log.py               # Rich console logging
│   ├── models.py            # Pydantic data models
│   ├── hubspot_client.py    # HubSpot API client
│   ├── storage.py           # CSV and SQLite storage
│   ├── analysis.py          # Lead scoring and insight generation (Phase 3)
│   └── reporting.py         # Rich output and SQLite rollups (Phase 3)
├── cli.py                   # CLI entry point
├── pyproject.toml           # Dependencies
├── .env.example             # Environment template
├── .gitignore               # Git ignore patterns
└── README.md                # This file
```

## Default Contact Properties

The CLI fetches these contact properties by default:
- `email`
- `firstname`
- `lastname`
- `phone`
- `company`

Additional metadata:
- `id` (HubSpot contact ID)
- `hs_object_id` (HubSpot object ID)
- `createdAt` (creation timestamp)
- `updatedAt` (last modified timestamp)

## Storage Formats

### CSV Format
Human-readable CSV file with all contact fields:
```csv
id,email,firstname,lastname,phone,company,hs_object_id,createdAt,updatedAt
123,john@example.com,John,Doe,555-1234,Acme Inc,123,2024-01-01,2024-10-24
```

### SQLite Database
Located at `ada.db` with table `contacts`:
- Automatic table creation
- Upsert on `id` field (INSERT OR REPLACE)
- All contact fields as columns

Query example:
```bash
sqlite3 ada.db "SELECT * FROM contacts LIMIT 5;"
```

## Error Handling

### Missing Token
```
Configuration Error: HUBSPOT_TOKEN missing or invalid. Set it via: export HUBSPOT_TOKEN='pat-...' or use Replit Secrets.
```

### Rate Limiting
- Automatic retry with exponential backoff
- Respects `Retry-After` header from HubSpot
- Logs warning messages during rate limit events

### Partial Data
- Gracefully handles missing contact properties
- Fills missing fields with `None`
- Continues processing remaining contacts

### Network Errors
- 30-second timeout per request
- Up to 5 retry attempts for 429/5xx errors
- Clear error messages for debugging

## Example Commands

```bash
# List all owners
python cli.py owners

# Fetch 5 contacts for testing
python cli.py pull-contacts --limit 5 --out test.csv

# Fetch 500 contacts to production file
python cli.py pull-contacts --limit 500 --out contacts.csv

# Fetch 1000 contacts (will paginate automatically)
python cli.py pull-contacts --limit 1000 --out all_contacts.csv
```

## Acceptance Tests

1. **List Owners Test**
   ```bash
   python cli.py owners
   ```
   Should print at least one owner with ID, email, and name.

2. **Pull Contacts Test**
   ```bash
   python cli.py pull-contacts --limit 5 --out contacts.csv
   ```
   Should create:
   - `contacts.csv` with ≥1 row
   - `ada.db` with ≥1 row in `contacts` table

3. **Error Handling Test**
   ```bash
   unset HUBSPOT_TOKEN
   python cli.py owners
   ```
   Should display: "HUBSPOT_TOKEN missing or invalid."

## Dependencies

All dependencies are managed via `uv` (automatically installed):
- **httpx** - Modern HTTP client with timeout support
- **pydantic** - Data validation and normalization
- **python-dotenv** - Environment variable management
- **tenacity** - Retry logic with exponential backoff
- **rich** - Beautiful console output

## Architecture Highlights

- **Clean Architecture**: Small, focused modules with single responsibilities
- **Type Safety**: Full type hints throughout the codebase
- **Resilient**: Pagination, rate-limiting, retries, timeouts
- **Testable**: Pure functions, dependency injection, clear interfaces
- **Documented**: Comprehensive docstrings and inline comments
- **Secure**: No hardcoded secrets, environment-based configuration

## Future Enhancements

- Incremental sync based on `updatedAt` timestamps
- Contact search and filtering via HubSpot API
- Support for Companies, Deals, and Tickets
- Additional export formats (JSON, Parquet)
- Batch processing for very large datasets
- Unit tests with mocked API responses
- Progress bars for long-running operations

## License

This project is provided as-is for demonstration purposes.
