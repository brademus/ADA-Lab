"""
ADA CLI - Command-line interface for HubSpot data operations.

Acceptance Tests:
    1. Running `python cli.py owners` prints at least one owner.
    2. Running `python cli.py pull-contacts --limit 5 --out contacts.csv` 
       creates contacts.csv and ada.db with ≥1 row.
    3. Invalid/missing token → clear error: "HUBSPOT_TOKEN missing or invalid."
    4. Running `python cli.py analyze --source csv --path contacts.csv --out-dir reports`
       creates lead_scores.csv, lead_scores.jsonl, insights.jsonl, summary.md

Example Commands:
    export HUBSPOT_TOKEN="pat-..."
    python cli.py owners
    python cli.py pull-contacts --limit 50 --out contacts.csv
    python cli.py analyze --source sqlite --path ada.db --out-dir reports
"""

import argparse
import sys
import time
from typing import List, Literal
from pathlib import Path

from rich.console import Console
from rich.table import Table
from rich import print as rprint

from ada.config import get_config, ConfigError
from ada.hubspot_client import HubSpotClient, HubSpotAPIError
from ada.models import Contact, normalize_hs_contact
from ada.storage import write_contacts_csv, write_contacts_sqlite
from ada.log import get_logger
from ada.analysis import (
    load_contacts,
    score_contact,
    insight_dormant,
    insight_top_engaged,
    insight_duplicates_by_email,
    insight_owner_load,
    insight_funnel_counts,
    to_csv,
    to_jsonl,
    LeadScore,
    Insight,
)
from ada.reporting import (
    render_summary,
    print_rich_summary,
    write_rollups_sqlite,
)

logger = get_logger(__name__)
console = Console()


def cmd_owners() -> int:
    """
    List HubSpot owners.
    
    Returns:
        Exit code (0 for success, 1 for failure).
    """
    try:
        config = get_config()
        
        with console.status("[bold green]Fetching owners from HubSpot..."):
            with HubSpotClient(config.hubspot_token) as client:
                owners = client.list_owners()
        
        if not owners:
            console.print("[yellow]No owners found.[/yellow]")
            return 0
        
        table = Table(title=f"HubSpot Owners ({len(owners)} total)")
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Email", style="magenta")
        table.add_column("Name", style="green")
        
        for owner in owners:
            owner_id = owner.get("id", "N/A")
            email = owner.get("email", "N/A")
            first_name = owner.get("firstName", "")
            last_name = owner.get("lastName", "")
            full_name = f"{first_name} {last_name}".strip() or "N/A"
            
            table.add_row(owner_id, email, full_name)
        
        console.print(table)
        return 0
        
    except ConfigError as e:
        console.print(f"[bold red]Configuration Error:[/bold red] {e}", style="red")
        return 1
    except HubSpotAPIError as e:
        console.print(f"[bold red]HubSpot API Error:[/bold red] {e}", style="red")
        return 1
    except Exception as e:
        console.print(f"[bold red]Unexpected Error:[/bold red] {e}", style="red")
        logger.exception("Unexpected error in cmd_owners")
        return 1


def cmd_pull_contacts(limit: int, output_path: str) -> int:
    """
    Pull contacts from HubSpot and save to CSV and SQLite.
    
    Args:
        limit: Maximum number of contacts to fetch.
        output_path: Output CSV file path.
        
    Returns:
        Exit code (0 for success, 1 for failure).
    """
    try:
        config = get_config()
        start_time = time.time()
        
        console.print(f"[bold]Fetching up to {limit} contacts from HubSpot...[/bold]")
        
        contacts: List[Contact] = []
        
        with console.status("[bold green]Fetching contacts..."):
            with HubSpotClient(config.hubspot_token) as client:
                for raw_contact in client.list_contacts(limit=limit):
                    try:
                        contact = normalize_hs_contact(raw_contact)
                        contacts.append(contact)
                    except Exception as e:
                        logger.warning(f"Failed to normalize contact: {e}")
                        continue
        
        if not contacts:
            console.print("[yellow]No contacts fetched.[/yellow]")
            return 0
        
        console.print(f"[green]✓[/green] Fetched and normalized {len(contacts)} contacts")
        
        with console.status("[bold green]Saving to CSV..."):
            write_contacts_csv(output_path, contacts)
        
        console.print(f"[green]✓[/green] Saved to {output_path}")
        
        db_path = "ada.db"
        with console.status("[bold green]Saving to SQLite..."):
            write_contacts_sqlite(db_path, contacts)
        
        console.print(f"[green]✓[/green] Saved to {db_path}")
        
        duration = time.time() - start_time
        
        table = Table(title="Summary")
        table.add_column("Metric", style="cyan")
        table.add_column("Value", style="green")
        
        table.add_row("Total Fetched", str(len(contacts)))
        table.add_row("Normalized", str(len(contacts)))
        table.add_row("Written to CSV", output_path)
        table.add_row("Written to DB", db_path)
        table.add_row("Duration", f"{duration:.2f}s")
        
        console.print(table)
        return 0
        
    except ConfigError as e:
        console.print(f"[bold red]Configuration Error:[/bold red] {e}", style="red")
        return 1
    except HubSpotAPIError as e:
        console.print(f"[bold red]HubSpot API Error:[/bold red] {e}", style="red")
        return 1
    except Exception as e:
        console.print(f"[bold red]Unexpected Error:[/bold red] {e}", style="red")
        logger.exception("Unexpected error in cmd_pull_contacts")
        return 1


def cmd_analyze(
    source: Literal["sqlite", "csv"],
    path: str,
    out_dir: str
) -> int:
    """
    Analyze contacts and generate lead scores and insights.
    
    Args:
        source: Data source type (sqlite or csv).
        path: Path to data file.
        out_dir: Output directory for reports.
        
    Returns:
        Exit code (0 for success, 1 for failure).
    """
    try:
        start_time = time.time()
        
        console.print(f"[bold]Loading contacts from {source}: {path}...[/bold]")
        
        contacts = load_contacts(source, path)
        
        if not contacts:
            console.print("[yellow]No contacts found. Nothing to analyze.[/yellow]")
            return 0
        
        console.print(f"[green]✓[/green] Loaded {len(contacts)} contacts")
        
        console.print("[bold]Scoring contacts...[/bold]")
        scores: List[LeadScore] = []
        
        with console.status("[bold green]Computing lead scores..."):
            for contact in contacts:
                try:
                    score = score_contact(contact)
                    scores.append(score)
                except Exception as e:
                    logger.warning(f"Failed to score contact {contact.get('id')}: {e}")
                    continue
        
        console.print(f"[green]✓[/green] Scored {len(scores)} contacts")
        
        console.print("[bold]Generating insights...[/bold]")
        insights: List[Insight] = []
        
        with console.status("[bold green]Analyzing data..."):
            insights.extend(insight_dormant(contacts, days=30))
            insights.extend(insight_top_engaged(scores, top_n=10))
            insights.extend(insight_duplicates_by_email(contacts))
            insights.extend(insight_owner_load(contacts))
            insights.extend(insight_funnel_counts(contacts))
        
        console.print(f"[green]✓[/green] Generated {len(insights)} insights")
        
        out_path = Path(out_dir)
        out_path.mkdir(parents=True, exist_ok=True)
        
        console.print(f"[bold]Saving reports to {out_dir}/...[/bold]")
        
        to_csv(scores, str(out_path / "lead_scores.csv"))
        to_jsonl(scores, str(out_path / "lead_scores.jsonl"))
        to_jsonl(insights, str(out_path / "insights.jsonl"))
        
        summary_md = render_summary(scores, insights)
        summary_path = out_path / "summary.md"
        summary_path.write_text(summary_md, encoding="utf-8")
        
        console.print(f"[green]✓[/green] Saved lead_scores.csv")
        console.print(f"[green]✓[/green] Saved lead_scores.jsonl")
        console.print(f"[green]✓[/green] Saved insights.jsonl")
        console.print(f"[green]✓[/green] Saved summary.md")
        
        db_path = "ada.db"
        console.print(f"[bold]Writing rollups to {db_path}...[/bold]")
        write_rollups_sqlite(db_path, scores, insights)
        console.print(f"[green]✓[/green] Updated {db_path}")
        
        duration = time.time() - start_time
        
        console.print()
        print_rich_summary(scores, insights)
        
        console.print(f"\n[bold green]Analysis complete in {duration:.2f}s[/bold green]")
        console.print(f"[dim]Reports saved to: {out_dir}/[/dim]\n")
        
        return 0
        
    except FileNotFoundError as e:
        console.print(f"[bold red]File Error:[/bold red] {e}", style="red")
        return 1
    except Exception as e:
        console.print(f"[bold red]Unexpected Error:[/bold red] {e}", style="red")
        logger.exception("Unexpected error in cmd_analyze")
        return 1


def main() -> int:
    """
    Main CLI entry point.
    
    Returns:
        Exit code.
    """
    parser = argparse.ArgumentParser(
        description="ADA - HubSpot Data Connection Layer CLI",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    
    subparsers = parser.add_subparsers(dest="command", help="Available commands")
    
    subparsers.add_parser("owners", help="List HubSpot owners")
    
    pull_parser = subparsers.add_parser(
        "pull-contacts", 
        help="Pull contacts from HubSpot and save locally"
    )
    pull_parser.add_argument(
        "--limit",
        type=int,
        default=100,
        help="Maximum number of contacts to fetch (default: 100)",
    )
    pull_parser.add_argument(
        "--out",
        type=str,
        default="contacts.csv",
        help="Output CSV file path (default: contacts.csv)",
    )
    
    analyze_parser = subparsers.add_parser(
        "analyze",
        help="Analyze contacts and generate lead scores and insights"
    )
    analyze_parser.add_argument(
        "--source",
        type=str,
        choices=["sqlite", "csv"],
        required=True,
        help="Data source type: sqlite or csv",
    )
    analyze_parser.add_argument(
        "--path",
        type=str,
        required=True,
        help="Path to data file (e.g., ada.db or contacts.csv)",
    )
    analyze_parser.add_argument(
        "--out-dir",
        type=str,
        default="reports",
        help="Output directory for reports (default: reports)",
    )
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return 1
    
    if args.command == "owners":
        return cmd_owners()
    elif args.command == "pull-contacts":
        return cmd_pull_contacts(args.limit, args.out)
    elif args.command == "analyze":
        return cmd_analyze(args.source, args.path, args.out_dir)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
