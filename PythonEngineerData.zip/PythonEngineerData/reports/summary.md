# ADA Analysis Summary

## Score Overview

- Total Contacts: 2
- Median Quality (P50): 60
- P90 Quality: 60
- Max Quality: 60

## Score Distribution

- 0-39: 0
- 40-59: 0
- 60-79: 2
- 80-100: 0

## Top 10 Leads

1. emailmaria@hubspot.com - Q=60, F=100, E=0 (updatedAt 0d ago)
2. bh@hubspot.com - Q=60, F=100, E=0 (updatedAt 0d ago)

## Insights (3 total)

### Top 2 engaged leads
- Type: top_engaged
- Severity: info

### Contact distribution across 1 owners
- Type: owner_load
- Severity: info

### Funnel breakdown
- Type: funnel
- Severity: info
- Lifecycle: {
  "unknown": 2
}
